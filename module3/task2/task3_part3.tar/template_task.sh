#!/bin/bash

script_name=$(basename "$0")

if [script_name == "template_task.sh"]
then 
	echo "я бригадир, сам не работаю"
	exit 0
fi

log_file="report_${script_name}.log"

pid=$$
start_time=$(date '+%Y-%m-%d %H:%M:%S')

echo "[$pid] $start_time Скрипт запущен" >> "$log_file"

sleep_seconds=$(( RANDOM % 1800 - 30 + 1 + 30 ))  

sleep "$sleep_seconds"

end_time=$(date '+%Y-%m-%d %H:%M:%S')

worked_minutes=$(( sleep_seconds / 60 ))
echo "[$pid] $end_time Скрипт завершился, работал $worked_minutes минут" >> "$log_file"
