#!/bin/bash

config_file="observer.conf"
log_file="observer.log"

while read -r script; do 
	if pgrep -f $script ; then
echo "Скрипт $script запущен" >> $log_file
else
nohup "$(pwd)/$script" &
date=$(date "+%d.&m.%Y %H:%M:%S")
echo "Скрипт $script перезапущен в Sdate" >> §log_file
fi
done < $config_file
